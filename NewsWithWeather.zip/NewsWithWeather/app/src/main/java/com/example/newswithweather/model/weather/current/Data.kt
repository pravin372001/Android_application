package com.example.newswithweather.model.weather.current

data class Data(
    val time: String,
    val values: Values
)