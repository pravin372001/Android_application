package com.example.newswithweather.model.weather.current

data class Weather(
    val `data`: Data,
    val location: Location
)