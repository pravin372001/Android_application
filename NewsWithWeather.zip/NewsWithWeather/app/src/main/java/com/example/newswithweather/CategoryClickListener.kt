package com.example.newswithweather

interface CategoryClickListener {
    fun onCategoryClicked(category: String)
}
