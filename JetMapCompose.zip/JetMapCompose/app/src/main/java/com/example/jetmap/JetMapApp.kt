package com.example.jetmap

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class JetMapApp: Application()