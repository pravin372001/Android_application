package com.example.jetmap.feature_google_places.domain.model

data class Distance(
    val text: String,
    val value: Int
)
