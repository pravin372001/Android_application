package com.example.jetmap.featur_typicode_users.domain.model

data class UserInfo(
//    val address: Address,
//    val company: Company,
    val email: String,
    val id: Int,
    val name: String,
    val phone: String,
    val username: String,
    val website: String
)
