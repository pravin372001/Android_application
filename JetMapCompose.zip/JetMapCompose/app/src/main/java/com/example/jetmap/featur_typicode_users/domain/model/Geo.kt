package com.example.jetmap.featur_typicode_users.domain.model

data class Geo(
    val lat: String,
    val lng: String
)
