package com.example.jetmap.feature_google_places.domain.model

data class Legs(
    val distance: Distance,
    val duration: Duration
)
