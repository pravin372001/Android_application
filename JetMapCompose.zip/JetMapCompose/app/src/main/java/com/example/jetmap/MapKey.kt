package com.example.jetmap

interface MapKey {
    companion object {
        const val KEY = "AIzaSyBpDkR1Nxe2NV6OeI9FKQYZfWcOZNAgN5c"
    }
}