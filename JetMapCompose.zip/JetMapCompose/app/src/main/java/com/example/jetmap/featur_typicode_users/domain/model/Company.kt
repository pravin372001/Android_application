package com.example.jetmap.featur_typicode_users.domain.model

data class Company(
    val bs: String,
    val name: String
)
